# Chapter 5: ContextGuard & Zone Enforcement - Iron Discipline

In this chapter, we dive deep into Theus v2's protection mechanisms: **Guard** and **Zone**.

## 1. Immutability & Unlocking
This is the core principle: **"Everything is Immutable until Unlocked."**

### Frozen Structures
When you read a List/Dict from Context with only read permission (`inputs`):
- Engine returns `FrozenList` or `FrozenDict`.
- Modification methods (`append`, `pop`, `update`, `__setitem__`) are disabled.
- You can only read (`get`, `len`, `iter`).

### Tracked Structures
When you have write permission (`outputs`):
- Engine returns `TrackedList` or `TrackedDict`.
- Modification is allowed, but it logs to `Transaction Delta` instead of modifying the original data immediately (Shadow Mechanism).

## 2. Zone Enforcement (The Zone Police)
The Guard checks not just permissions, but **Architecture**.

### Input Guard
In `ContextGuard` initialization, Theus v2 checks all `inputs`:
```python
# Engine Pseudo-code
for inp in inputs:
    if is_signal_zone(inp) or is_meta_zone(inp):
        raise ContractViolationError("Cannot use Signal/Meta as Input!")
```
This prevents Process logic from depending on non-persistent values.

### Output Guard
Conversely, you are allowed to write to any Zone (Data, Signal, Meta) as long as you declare it in `outputs`.

## 3. Zero Trust Memory
Theus does not believe in "temporary variables".
```python
# Bad Code (Theus warns or blocks)
my_list = ctx.domain.items
# ... do something long ...
my_list.append(x) # Dangerous! my_list might be Stale
```
Theus encourages (and Proxy forces) you to always access via `ctx.` to ensure you are interacting with the latest and valid version of data within the current Transaction.

---
**Exercise:**
Try to "hack" the Guard.
1. Declare `inputs=['domain.items']` (but NO outputs).
2. Inside the function, try calling `ctx.domain.items.append(1)`.
3. Observe the `FrozenListError` (or similar) to witness Theus's protection.
